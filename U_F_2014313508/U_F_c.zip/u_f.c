#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
typedef struct score score;
struct score{
	char name[10];
	int a;
	int b;
	int c;
	int d;
	int e;
	int total;
};

int finF_cc(int s){
	int score = 14-s;
	if (score < 4){
		return (100-(score*5));
	}
	else{
		return 0;
	}
}

int finF_HW(int s){
	int score = 22-s;
	if (score <= 3){
		return (100-(score*5));
	}
	else{
		return 0;
	}
}

int finF_MT(int s){
	if (s>=60){
		return s;
	}
	else{
		return 0;
	}
}

int finF_Q(int s){
	if (s>=80){
		return s;
	}
	else{
		return 0;
	}
}

int finF_F(int s){
	if (s>=60){
		return s;
	}
	else{
		return 0;
	}
}

void Sort(score *base, int n)//��ǰ ����(��������)
{
   	score temp;
   	int i = 0, j = 0;
   	for (i = n; i > 1; i--)
   	{
       	for (j = 1; j < i; j++)
       	{
           	if (base[j - 1].total<base[j].total)//���� �л��� ������ ���� ��
           	{
               	//�� ���� ������ ��ȯ
               	temp = base[j-1];
               	base[j - 1] = base[j];
               	base[j] = temp;
           	}
       	}
   	}
}

int flist[100] = {-1,};


int main(int argc, char *argv[]) {
	int i,tmp;
	int cnt = 0, colcnt = 0; //ī��Ʈ
    char *pStr; //���� ������
    struct score arr[100] = { 0 }; //100���� ����ü ����
    FILE* fp = fopen("�����ͼ�.csv", "rb"); //���Ͽ���
    char buff[2500] = {}; //����
    tmp = 0;
    if (fp != NULL) //�о�� �͵��� ���� �ƴҵ���
    {
        while (!feof(fp))//������ ���پ� ���������� ������
        {
            pStr = fgets(buff, sizeof(buff), fp);
            if (colcnt >= 1)//colcnt�� �� ��Ʈ��
            {
                if (pStr == NULL)
                break;
                sscanf(pStr, "%[^,],%d,%d,%d,%d,%d\n", &arr[cnt].name, &arr[cnt].a, &arr[cnt].b, &arr[cnt].c, &arr[cnt].d, &arr[cnt].e);
                cnt++;
            }
            else
                colcnt++;
        }
        fclose(fp);
    }
        
    for (i=0; i < 100; i++){
    	int score = finF_cc(arr[i].a);
    	if (score == 0) {
    		flist[i] = 1;
		}
		else{
			arr[i].a = score;
		}
	}
	
	for (i=0; i < 100; i++){
		if (flist[i] != 1){
			int score = finF_HW(arr[i].b);
    		if (score == 0) {
    			flist[i] = 1;
			}
			else{
				arr[i].b = score;
			}
		}	
	}
	
	for (i=0; i < 100; i++){
		if (flist[i] != 1){
			int score = finF_MT(arr[i].c);
    		if (score == 0) {
    			flist[i] = 1;
			}
			else{
				arr[i].c = score;
			}
		}	
	}
	
	for (i=0; i < 100; i++){
		if (flist[i] != 1){
			int score = finF_Q(arr[i].d);
    		if (score == 0) {
    			flist[i] = 1;
			}
			else{
				arr[i].d = score;
			}
		}	
	}
	
	for (i=0; i < 100; i++){
		if (flist[i] != 1){
			int score = finF_F(arr[i].e);
    		if (score == 0) {
    			flist[i] = 1;
			}
			else{
				arr[i].e = score;
			}
		}	
	}
    
    
	
	int fcnt = 0;			//f�� �ƴ��� ����ΰ�? 
	for(i=0; i < 100; i++){
		if (flist[i] != 1){
			arr[i].total = arr[i].a + arr[i].b + arr[i].c + arr[i].d + arr[i].e;
			fcnt ++;
		}
	}
	
    
    Sort(arr, 100);		// ������ �������� ���� 

	
	for(i=0; i < 100; i++){
		if (i < 50 && arr[i].total != 0){
			printf("%s A+\n", arr[i].name);
		} 
		else if(i < 90 && arr[i].total != 0){
			printf("%s B+\n", arr[i].name);
		} 
		else if(arr[i].total != 0){
			printf("%s C+\n", arr[i].name);
		} 
		else{
			printf("%s F\n", arr[i].name);
		}
	}

	
	return 0;
}
