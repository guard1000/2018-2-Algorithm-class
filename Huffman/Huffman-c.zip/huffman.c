#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
typedef struct huffman huffman;
int n;
int m=0; 
struct huffman{
	int name;
	float value; // �� 
	int ans[10];
	int hp;
};


void Sort(huffman *base, int n, int m)//��ǰ ����(��������)
{
   	huffman temp;
   	int i = m, j = m;
   	for (i = m; i < n-1; i++)
   	{
       	for (j = m+1; j < n; j++)
       	{
           	if (base[j - 1].value > base[j].value)//���� �� �� ���� ��
           	{
               	// ������ ��ȯ
               	temp = base[j-1];
               	base[j - 1] = base[j];
               	base[j] = temp;
           	}
       	}
   	}
}


int main(int argc, char *argv[]) {
	int i,j,k;
	int p,q;
	float val;
	char  str_buffer[30];
    char *ptr;
	struct huffman arr[30] = { 0 }; //30���� ����ü ����
	int tmp;
	
	printf("��� ���Ұ� �ֳ���?(10�� ����!)\n");
	scanf("%d", &n);
	for(i=0; i<n; i++){
		printf("%d ��° �Է�(��:�̸�(���ڸ� �ڿ���) ��): ",i+1);
		scanf("%d %f", &arr[i].name, &arr[i].value);
	}
	
	printf("ó�� �Է���\n");
	for(i=0; i<n; i++){
		printf("[%d : %.2f] ",arr[i].name, arr[i].value);
	}
	printf("\n\nHuffman�� ���ư��ϴ�.\n\n");
	
	
	
	while ((n-m)>1){
		Sort(arr, n, m);
		for(i=m; i<n; i++){	//���ư��� ��� ������ 
			printf("[%d : %.2f] ",arr[i].name, arr[i].value);
		}
		printf("\n");
		
		tmp = arr[m].name;
		while((tmp/10) >= 1) {
			for(k=0; k<n; k++){
				if (arr[k].name == (tmp%10)){
					arr[k].ans[arr[k].hp] = 0;
					arr[k].hp = arr[k].hp + 1;
				}	
			}
			tmp = tmp/10; 
		}
		for(k=0; k<n; k++){
			if (arr[k].name == tmp){
				arr[k].ans[arr[k].hp] = 0;
				arr[k].hp = arr[k].hp + 1;
			}	
		}
		
		tmp = arr[m+1].name;
		while((tmp/10) >= 1) {
			for(k=0; k<n; k++){
				if (arr[k].name == (tmp%10)){
					arr[k].ans[arr[k].hp] = 1;
					arr[k].hp = arr[k].hp + 1;
				}	
			}
			tmp = tmp/10; 
		}
		for(k=0; k<n; k++){
			if (arr[k].name == tmp){
				arr[k].ans[arr[k].hp] = 1;
				arr[k].hp = arr[k].hp + 1;
			}	
		}
		
		
		j=1;
		while ((arr[m+1].name / j )>= 1){		//�̸� ���� 
			j = j*10;
		} 
		
		arr[n].name = arr[m].name*j + arr[m+1].name;
		arr[n].value = arr[m].value + arr[m+1].value;
		m = m+2;
		n = n+1;	
	}
	printf("\n");
	for(p=0;p<n;p++){
		if (arr[p].name < 10 ){
			printf("%d: ", arr[p].name);
			for(q=arr[p].hp-1;q>=0;q--){
				printf("%d",arr[p].ans[q]);
			}
			printf("\n");
		} 
	}		
	
	
	
	
	return 0;
}
