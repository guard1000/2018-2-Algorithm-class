#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
float inp[3][4];

void show(){
	int i;
	
	for (i=0; i<3; i++){
		printf("[%.1f %.1f %.1f %.1f]\n", inp[i][0], inp[i][1], inp[i][2], inp[i][3]);
	}
}

int main(int argc, char *argv[]) {
	int i,j;
	float tmp;
	printf("Welcome to Gaussian Elimination!\n");
	printf("a1x + b1y +c1z = d1\na2x + b2y +c2z = d2\na3x + b3y +c3z = d3\n");
	
	int nodap = 0;
	for (i = 1; i<=3; i++){
		printf("a%d b%d c%d d%d�� ������� �Է����ּ���", i,i,i,i);
		scanf("%f %f %f %f", &inp[i-1][0], &inp[i-1][1], &inp[i-1][2], &inp[i-1][3]);
	}

	show();
	
	printf("STEP 1\n");
	for (i = 1; i < 3; i++){
		if (inp[0][0] != 0){
			tmp	=  (inp[i][0] / inp[0][0]);
			for (j=0; j<4; j++){
				inp[i][j] = inp[i][j] - (inp[0][j]*tmp);
			}
		}
	}
	show();
	
	printf("\n\nSTEP 2\n");
	if(inp[1][1] != 0) {
		tmp = (inp[2][1] / inp[1][1]);
		for (j=0; j<4; j++){
				inp[2][j] = inp[2][j] - (inp[1][j]*tmp);
			}
	}
	show();
	
	printf("\n\nSTEP 3\n");
	for (i = 1; i > -1; i--){
		if (inp[2][2] != 0){
			tmp	=  (inp[i][2] / inp[2][2]);
			for (j=0; j<4; j++){
				inp[i][j] = inp[i][j] - (inp[2][j]*tmp);
			}
		}
	}
	show();
	
	printf("\n\nSTEP 4\n");
	if(inp[1][1] != 0) {
		tmp = (inp[0][1] / inp[1][1]);
		for (j=0; j<4; j++){
				inp[0][j] = (inp[0][j] - (inp[1][j]*tmp));
			}
	}
	show();
	
	printf("\n\nSTEP 5 - �ϼ���\n");
	for (i=0; i<3; i++) {
		if (inp[i][i] != 0) {
			inp[i][3] = inp[i][3] / inp[i][i];
			inp[i][i] = 1.0;
		}
		else{
			nodap = 1;
		}
	}
	show();
	
	if (nodap == 0) {
		printf("x = %.1f\n", inp[0][3]);
		printf("y = %.1f\n", inp[1][3]);
		printf("z = %.1f\n", inp[2][3]);
	}
	else{
		printf("�ذ� ���� ���̱���!\n");
	}


	
	return 0;
}

